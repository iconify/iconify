import { Icon } from '@iconify/css-solid';
import { splitProps } from 'solid-js';
import '../css/test78832u.css';

const viewBox = {"width":24,"height":24};
const content = `<path class="test78832u"/>`;

interface Props {
	width?: string;
	height?: string;
};

function Component<Props>(props) {
	const [local, others] = splitProps(props, ["width","height"]);

	return (<Icon width={local.width} height={local.height} viewBox={viewBox} content={content} fallback={"ri:twitter-x-line"} {...others} />);
}

export default Component;
