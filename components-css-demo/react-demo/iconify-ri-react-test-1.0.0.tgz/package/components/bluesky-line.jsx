import { Icon } from '@iconify/css-react';
import { createElement } from 'react';
import '../css/testmy5efa.css';

const viewBox = {"width":24,"height":24};

/** @type {{width?: string; height?: string;}} */
function Component({width, height, ...props}) {
	return createElement(Icon, {
		...props,
		width,
		height,
		viewBox,
		"content": `<path class="testmy5efa"/>`,
		"fallback": "ri:bluesky-line",
	});
}

export default Component;
