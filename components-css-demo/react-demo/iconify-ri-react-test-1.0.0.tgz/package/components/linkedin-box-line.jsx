import { Icon } from '@iconify/css-react';
import { createElement } from 'react';
import '../css/testlg5dgz.css';

const viewBox = {"width":24,"height":24};

/** @type {{width?: string; height?: string;}} */
function Component({width, height, ...props}) {
	return createElement(Icon, {
		...props,
		width,
		height,
		viewBox,
		"content": `<path class="testlg5dgz"/>`,
		"fallback": "ri:linkedin-box-line",
	});
}

export default Component;
