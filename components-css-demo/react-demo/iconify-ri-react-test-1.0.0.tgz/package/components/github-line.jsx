import { Icon } from '@iconify/css-react';
import { createElement } from 'react';
import '../css/testo40dnh.css';

const viewBox = {"width":24,"height":24};

/** @type {{width?: string; height?: string;}} */
function Component({width, height, ...props}) {
	return createElement(Icon, {
		...props,
		width,
		height,
		viewBox,
		"content": `<path class="testo40dnh"/>`,
		"fallback": "ri:github-line",
	});
}

export default Component;
